export const colors = {
    primary: '#2A3FF8',
    secondary: '#FF2457',
    dark: '#1E1E1E',
    light: '#ADADAD',
    black: '#050505',
    yellow: '#FEF667'
}