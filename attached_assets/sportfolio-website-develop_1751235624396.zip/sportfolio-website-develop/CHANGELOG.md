# [0.1.0]
## Initial Setup
- configured nextjs with react
- landing page