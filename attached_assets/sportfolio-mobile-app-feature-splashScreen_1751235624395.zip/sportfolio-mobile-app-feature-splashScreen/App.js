import * as React from 'react';
import RootStack from './src/navigators/RootStack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { View } from 'react-native';
function App() {
    return (
        // <GestureHandlerRootView>
        <RootStack />
        // </GestureHandlerRootView>
    );
}

export default App;
