import { StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import {
    responsiveHeight,
    responsiveWidth,
    responsiveFontSize
} from "react-native-responsive-dimensions";
const Login = () => {

    return (
        <View style={{
            backgroundColor: 'red', height: responsiveHeight(50),
            width: responsiveWidth(50)
        }}>
            <Text>Login</Text>
        </View>
    );
};
export default Login;