import { StyleSheet, Dimensions } from 'react-native';
import colors from '../../constants/Colors/colors';
import fonts from '../../constants/Fonts/fonts';
import {
    responsiveScreenHeight,
    responsiveScreenWidth,
    responsiveScreenFontSize,
} from 'react-native-responsive-dimensions';
const { width, height } = Dimensions.get('window');

export const globalStyles = StyleSheet.create({
    myView1: {
        backgroundColor: colors.PRIMARY_COLOR,
        width: width,
        height: height,
    },
    subView1: {
        height: height * 0.65,
    },
    subView2: {
        height: height * 0.05,
        alignItems: 'center',
    },
    subView3: {
        height: height * 0.13,
        alignItems: 'center',
    },
    subView4: {
        backgroundColor: colors.BOTTOM_BOX_COLOR,
        height: height * 0.19,
        borderRadius: responsiveScreenWidth(5),
        marginLeft: responsiveScreenWidth(4),
        marginRight: responsiveScreenWidth(4),
        justifyContent: 'center',
        alignItems: 'center',
    },
    Text1: {
        fontFamily: fonts.WORKSANS_REGULAR,
        fontSize: responsiveScreenFontSize(3.5),
        color: colors.WHITE_COLOR,
    },
    Text2: {
        fontFamily: fonts.WORKSANS_REGULAR,
        fontSize: responsiveScreenFontSize(2),
        color: colors.WHITE_COLOR,
    },
    Text3: {
        fontFamily: fonts.WORKSANS_REGULAR,
        fontSize: responsiveScreenFontSize(2),
        color: colors.POWERD_BY__COLOR,
    },
    mainImage1: {
        height: height * 0.28,
        flexDirection: 'row'
    },
    mainImage2: {
        alignItems: 'center'
    },
    Cloud1: {
        marginTop: responsiveScreenHeight(5),
        marginLeft: responsiveScreenWidth(50),
    },
    Cloud2: {
        marginTop: responsiveScreenHeight(5),
        marginLeft: responsiveScreenWidth(70),
    },
    Cloud3: {
        marginTop: responsiveScreenHeight(1),
        marginLeft: responsiveScreenWidth(90),
    },

})