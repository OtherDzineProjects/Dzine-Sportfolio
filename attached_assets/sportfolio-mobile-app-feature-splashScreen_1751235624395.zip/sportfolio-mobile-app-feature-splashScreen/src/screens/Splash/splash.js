import { StyleSheet, Text, View, Image } from 'react-native';
import React, { useEffect, useState } from 'react';
import {
    responsiveHeight,
    responsiveWidth,
    responsiveFontSize
} from "react-native-responsive-dimensions";
import { globalStyles } from './style';
import images from '../../constants/Images/images';
const Splash = ({ navigation }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            navigation.replace('Login');
        }, 2000);

        return () => clearTimeout(timer);
    }, [navigation]);

    return (
        <View style={globalStyles.myView1}>
            <View style={globalStyles.subView1}>
                <View style={globalStyles.mainImage1}>
                    {/* <View style={{ backgroundColor: 'green' }}>
                        <Image source={images.CLOUD_IMAGE} style={globalStyles.Cloud1}></Image>
                    </View>
                    <View style={{ backgroundColor: 'yellow' }}>
                        <Image source={images.CLOUD_IMAGE} style={globalStyles.Cloud2}></Image>
                    </View>
                    <View style={{ backgroundColor: 'red' }}>
                        <Image source={images.CLOUD_IMAGE} style={globalStyles.Cloud3}></Image>
                    </View> */}
                </View>
                <View style={globalStyles.mainImage2}>
                    <Image source={images.SPALASH_MAIN_IMAGE}>

                    </Image>
                </View>
            </View>
            <View style={globalStyles.subView2}>
                <Text style={globalStyles.Text1}>SPORTFOLIO</Text>
            </View>
            <View style={globalStyles.subView3}>
                <Text style={globalStyles.Text2}>lets’ play</Text>
            </View>
            <View style={globalStyles.subView4}>
                <Text style={globalStyles.Text3} >Powered by </Text>
                <Text style={globalStyles.Text3}> DZINE TECHNOLOGIES</Text>
            </View>
        </View >
    );
};
export default Splash;