export default {
    WORKSANS_REGULAR: 'WorkSans-Regular',
};