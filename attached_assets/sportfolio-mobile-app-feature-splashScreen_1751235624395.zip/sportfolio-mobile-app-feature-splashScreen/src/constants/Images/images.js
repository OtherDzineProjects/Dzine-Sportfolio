export default {
    SPALASH_MAIN_IMAGE: require('../../assets/Images/Splash_main_image.png'),
    CLOUD_IMAGE: require('../../assets/Images/Frame.png'),
};