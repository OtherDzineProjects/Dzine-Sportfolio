import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Login from '../screens/Login/login';
import Splash from '../screens/Splash/splash';
const Stack = createNativeStackNavigator();
function RootStack() {
    return (
        <NavigationContainer>
            <Stack.Navigator
                screenOptions={{
                    headerShown: false,
                }}
                initialRouteName={{ Splash }}
                options={{ gestureEnabled: false }}>
                <Stack.Screen name="Splash" component={Splash} options={{ headerShown: false }} />

                <Stack.Screen
                    name="Login"
                    component={Login}
                    options={{ headerShown: false }}
                />
            </Stack.Navigator>
        </NavigationContainer>
    );
}
export default RootStack;