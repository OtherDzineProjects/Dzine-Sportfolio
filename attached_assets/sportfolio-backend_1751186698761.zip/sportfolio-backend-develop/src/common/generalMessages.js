//General usage values

module.exports = {

    //to convert encrypted password to hex value //src/common/commonFunctions.js 
    convertTo_hex : "hex",
    //password encryption format //src/common/commonFunctions.js
    password_encriptionType : "sha3-256",
    //secret key for jwt token //src/common/commonFunctions.js
    secret_Key : "Sportfolio",
    //time frame for jwt token //src/common/commonFunctions.js
    token_Expiry : "24h"

}


