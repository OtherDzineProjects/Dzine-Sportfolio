# [0.0.5]
## add
- notification card

# [0.0.4]
## Update
- user and other contributors

# [0.0.4]
## Update
- user and other contributors

# [0.0.3]
## Connected
- Connected with backend POST AND GET success
- integrated with signup success

# [0.0.2]
## Layout
- Dashbaord Layout
- husky - link configured

# [0.0.1]
## Initial Commit
- consfigurations