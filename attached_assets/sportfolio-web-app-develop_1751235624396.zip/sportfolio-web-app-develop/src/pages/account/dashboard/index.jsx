
const Dashboard = () => {
  return (
    <div className="p-10">
      Dashboard
    </div>
  );
};

export default Dashboard;