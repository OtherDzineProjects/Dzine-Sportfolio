import ProfileStepper from "./components/ProfileStepper"

const Profile = () => {
  return (
    <div>
      <ProfileStepper />
    </div>
  )
}

export default Profile