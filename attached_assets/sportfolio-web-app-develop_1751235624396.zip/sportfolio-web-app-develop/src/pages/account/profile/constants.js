export const profileSteps = [
    'basic',
    'contact',
    'qualification',
    'family',
    'skills',
    'services',
    'achievements',
    'awards',
    'documents'
]