const Verification = () => {
  return (
    <div>Verification</div>
  );
};

export default Verification;