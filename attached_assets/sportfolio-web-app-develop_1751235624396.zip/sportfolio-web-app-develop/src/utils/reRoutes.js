export const reRoute = (url) =>{
    window.location.href = url
}